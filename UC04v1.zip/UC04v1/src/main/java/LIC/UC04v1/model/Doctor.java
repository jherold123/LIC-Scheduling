package LIC.UC04v1.model;

import javax.persistence.*;

@Entity
public class Doctor {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    @OneToOne
    private Clerkship clerkship;
    private String Name;

    public Doctor(){}

    public Doctor(int id) {
        this.id = id;
    }
}
