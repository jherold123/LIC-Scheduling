package LIC.UC04v1.repositories;

import LIC.UC04v1.model.Clerkship;
import org.springframework.data.repository.CrudRepository;

public interface ClerkshipRepository extends CrudRepository<Clerkship, Integer> {
}
