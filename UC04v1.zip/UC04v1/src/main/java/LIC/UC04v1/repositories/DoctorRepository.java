package LIC.UC04v1.repositories;

import LIC.UC04v1.model.Doctor;
import org.springframework.data.repository.CrudRepository;

public interface DoctorRepository extends CrudRepository<Doctor, Integer> {

}
